#include <Adafruit_NeoPixel.h>
#include <EEPROM.h>
#include <Wire.h>
#include <RTClib.h>

static constexpr uint8_t PIN_PIXELS = 5;
static constexpr uint8_t NUM_PIXELS = 31;
static constexpr uint8_t BTN1_PIN = 8;
static constexpr uint8_t BTN2_PIN = 9;
static constexpr uint8_t BTN3_PIN = 10;

static constexpr uint8_t EEPROM_ADDR_MAP = 0;
static constexpr uint8_t EEPROM_ADDR_SETTINGS = 128;
static constexpr uint32_t MAP_MAGIC = 0x4D415031UL;     // MAP1
static constexpr uint32_t SETTINGS_MAGIC = 0x434C4B31UL; // CLK1

Adafruit_NeoPixel pixels(NUM_PIXELS, PIN_PIXELS, NEO_GRB + NEO_KHZ800);
RTC_DS3231 rtc;

// 31 logical positions = 4 digits * 7 + colon * 2 + decimal * 1
// Keep this aligned with the calibration tool.
enum LogicalId : uint8_t {
  D1_A=0, D1_B, D1_C, D1_D, D1_E, D1_F, D1_G,
  D2_A, D2_B, D2_C, D2_D, D2_E, D2_F, D2_G,
  COLON_TOP, COLON_BOTTOM,
  D3_A, D3_B, D3_C, D3_D, D3_E, D3_F, D3_G,
  D4_A, D4_B, D4_C, D4_D, D4_E, D4_F, D4_G,
  DECIMAL,
  LOGICAL_COUNT = 31,
  LOG_UNUSED = 255
};

enum ClockMode : uint8_t {
  MODE_CLOCK = 0,
  MODE_SECONDS = 1,
  MODE_TIMER = 2,
  MODE_STOPWATCH = 3,
  MODE_COLOR_DEMO = 4,
  MODE_COUNT = 5
};

struct MappingBlob {
  uint32_t magic;
  uint8_t version;
  uint8_t numPixels;
  uint8_t physToLogical[NUM_PIXELS];
  uint16_t checksum;
};

struct SettingsBlob {
  uint32_t magic;
  uint8_t version;
  uint8_t brightness;
  uint8_t mode;
  uint8_t showLeadingZero;
  uint8_t hour24;
  uint8_t colonBlink;
  uint8_t reserved0;
  uint32_t colorClock;
  uint32_t colorAccent;
  uint32_t colorSeconds;
  uint32_t colorTimer;
  uint32_t colorOff;
  uint16_t checksum;
};

struct ButtonState {
  uint8_t pin;
  bool stablePressed;
  bool lastRead;
  uint32_t lastChangeMs;
  uint32_t pressedAtMs;
};

static uint8_t physToLogical[NUM_PIXELS];
static uint8_t logicalToPhys[LOGICAL_COUNT];

static SettingsBlob settings;

static bool rtcPresent = false;
static bool timeDirty = false;
static bool colonState = true;
static uint32_t lastSecondTick = 0;
static uint32_t lastDisplayMs = 0;
static uint32_t lastBlinkMs = 0;
static uint32_t lastDemoMs = 0;
static uint32_t stopwatchStartedAtMs = 0;
static uint32_t stopwatchAccumulatedMs = 0;
static bool stopwatchRunning = false;
static uint32_t timerDurationSec = 5 * 60;
static uint32_t timerEndUnix = 0;
static bool timerRunning = false;
static uint8_t demoHue = 0;

static ButtonState btn1 { BTN1_PIN, false, false, 0, 0 };
static ButtonState btn2 { BTN2_PIN, false, false, 0, 0 };
static ButtonState btn3 { BTN3_PIN, false, false, 0, 0 };

static const uint8_t kDigitMask[10] = {
  0b00111111,
  0b00000110,
  0b01011011,
  0b01001111,
  0b01100110,
  0b01101101,
  0b01111101,
  0b00000111,
  0b01111111,
  0b01101111
};

uint16_t checksum16(const uint8_t* data, size_t n) {
  uint16_t s = 0;
  for (size_t i = 0; i < n; i++) s = static_cast<uint16_t>(s + data[i]);
  return s;
}

void buildInverseMap() {
  for (uint8_t i = 0; i < LOGICAL_COUNT; i++) logicalToPhys[i] = LOG_UNUSED;
  for (uint8_t p = 0; p < NUM_PIXELS; p++) {
    uint8_t l = physToLogical[p];
    if (l < LOGICAL_COUNT) logicalToPhys[l] = p;
  }
}

bool validateNoDuplicates() {
  bool used[LOGICAL_COUNT];
  for (uint8_t i = 0; i < LOGICAL_COUNT; i++) used[i] = false;
  for (uint8_t p = 0; p < NUM_PIXELS; p++) {
    uint8_t l = physToLogical[p];
    if (l == LOG_UNUSED) continue;
    if (l >= LOGICAL_COUNT) return false;
    if (used[l]) return false;
    used[l] = true;
  }
  return true;
}

void setDefaultIdentityMap() {
  for (uint8_t i = 0; i < NUM_PIXELS; i++) physToLogical[i] = i;
  buildInverseMap();
}

void setDefaultSettings() {
  settings.magic = SETTINGS_MAGIC;
  settings.version = 1;
  settings.brightness = 48;
  settings.mode = MODE_CLOCK;
  settings.showLeadingZero = 1;
  settings.hour24 = 0;
  settings.colonBlink = 1;
  settings.reserved0 = 0;
  settings.colorClock = 0xFF7A18UL;
  settings.colorAccent = 0x2080FFUL;
  settings.colorSeconds = 0x00C878UL;
  settings.colorTimer = 0xFF1010UL;
  settings.colorOff = 0x000000UL;
  settings.checksum = 0;
}

void saveSettings() {
  settings.magic = SETTINGS_MAGIC;
  settings.version = 1;
  settings.checksum = 0;
  settings.checksum = checksum16(reinterpret_cast<const uint8_t*>(&settings), sizeof(SettingsBlob) - sizeof(settings.checksum));
  EEPROM.put(EEPROM_ADDR_SETTINGS, settings);
}

bool loadSettings() {
  SettingsBlob temp;
  EEPROM.get(EEPROM_ADDR_SETTINGS, temp);
  uint16_t calc = checksum16(reinterpret_cast<const uint8_t*>(&temp), sizeof(SettingsBlob) - sizeof(temp.checksum));
  if (temp.magic != SETTINGS_MAGIC || temp.version != 1 || temp.checksum != calc) {
    setDefaultSettings();
    return false;
  }
  settings = temp;
  return true;
}

void saveMap() {
  MappingBlob b;
  b.magic = MAP_MAGIC;
  b.version = 1;
  b.numPixels = NUM_PIXELS;
  for (uint8_t i = 0; i < NUM_PIXELS; i++) b.physToLogical[i] = physToLogical[i];
  b.checksum = checksum16(b.physToLogical, NUM_PIXELS);
  EEPROM.put(EEPROM_ADDR_MAP, b);
}

bool loadMap() {
  MappingBlob b;
  EEPROM.get(EEPROM_ADDR_MAP, b);
  if (b.magic != MAP_MAGIC) return false;
  if (b.version != 1) return false;
  if (b.numPixels != NUM_PIXELS) return false;
  if (b.checksum != checksum16(b.physToLogical, NUM_PIXELS)) return false;
  for (uint8_t i = 0; i < NUM_PIXELS; i++) physToLogical[i] = b.physToLogical[i];
  buildInverseMap();
  return validateNoDuplicates();
}

uint32_t colorWheel(uint8_t pos) {
  pos = 255 - pos;
  if (pos < 85) {
    return pixels.Color(255 - pos * 3, 0, pos * 3);
  }
  if (pos < 170) {
    pos -= 85;
    return pixels.Color(0, pos * 3, 255 - pos * 3);
  }
  pos -= 170;
  return pixels.Color(pos * 3, 255 - pos * 3, 0);
}

void clearPixels() {
  for (uint8_t i = 0; i < NUM_PIXELS; i++) pixels.setPixelColor(i, settings.colorOff);
}

void setLogical(uint8_t logical, uint32_t color) {
  if (logical >= LOGICAL_COUNT) return;
  uint8_t phys = logicalToPhys[logical];
  if (phys == LOG_UNUSED || phys >= NUM_PIXELS) return;
  pixels.setPixelColor(phys, color);
}

void setDigitSegments(uint8_t digitBaseLogical, uint8_t mask, uint32_t color) {
  for (uint8_t s = 0; s < 7; s++) {
    if (mask & (1 << s)) setLogical(static_cast<uint8_t>(digitBaseLogical + s), color);
  }
}

void renderDigitsRaw(int d1, int d2, int d3, int d4, bool colonOn, bool decimalOn, uint32_t digitColor, uint32_t accentColor) {
  clearPixels();
  if (d1 >= 0) setDigitSegments(D1_A, kDigitMask[d1 % 10], digitColor);
  if (d2 >= 0) setDigitSegments(D2_A, kDigitMask[d2 % 10], digitColor);
  if (d3 >= 0) setDigitSegments(D3_A, kDigitMask[d3 % 10], digitColor);
  if (d4 >= 0) setDigitSegments(D4_A, kDigitMask[d4 % 10], digitColor);
  if (colonOn) {
    setLogical(COLON_TOP, accentColor);
    setLogical(COLON_BOTTOM, accentColor);
  }
  if (decimalOn) setLogical(DECIMAL, accentColor);
  pixels.show();
}

void renderClockFace() {
  DateTime now = rtcPresent ? rtc.now() : DateTime(F(__DATE__), F(__TIME__)) + TimeSpan(millis() / 1000);
  int hour = now.hour();
  if (!settings.hour24) {
    hour = hour % 12;
    if (hour == 0) hour = 12;
  }
  int d1 = hour / 10;
  int d2 = hour % 10;
  int d3 = now.minute() / 10;
  int d4 = now.minute() % 10;
  if (!settings.showLeadingZero && d1 == 0) d1 = -1;
  renderDigitsRaw(d1, d2, d3, d4, colonState, false, settings.colorClock, settings.colorAccent);
}

void renderSecondsFace() {
  DateTime now = rtcPresent ? rtc.now() : DateTime(F(__DATE__), F(__TIME__)) + TimeSpan(millis() / 1000);
  int d1 = now.minute() / 10;
  int d2 = now.minute() % 10;
  int d3 = now.second() / 10;
  int d4 = now.second() % 10;
  renderDigitsRaw(d1, d2, d3, d4, colonState, false, settings.colorSeconds, settings.colorAccent);
}

void renderTimerFace() {
  uint32_t remaining = 0;
  if (timerRunning && rtcPresent) {
    DateTime now = rtc.now();
    uint32_t nowUnix = now.unixtime();
    if (nowUnix >= timerEndUnix) {
      remaining = 0;
      timerRunning = false;
    } else {
      remaining = timerEndUnix - nowUnix;
    }
  } else {
    remaining = timerDurationSec;
  }

  uint32_t mins = remaining / 60;
  uint32_t secs = remaining % 60;
  int d1 = (mins / 10) % 10;
  int d2 = mins % 10;
  int d3 = secs / 10;
  int d4 = secs % 10;
  renderDigitsRaw(d1, d2, d3, d4, colonState, false, settings.colorTimer, settings.colorAccent);
}

void renderStopwatchFace() {
  uint32_t elapsedMs = stopwatchAccumulatedMs;
  if (stopwatchRunning) elapsedMs += millis() - stopwatchStartedAtMs;
  uint32_t totalSec = elapsedMs / 1000;
  uint32_t mins = (totalSec / 60) % 100;
  uint32_t secs = totalSec % 60;
  renderDigitsRaw((mins / 10) % 10, mins % 10, secs / 10, secs % 10, colonState, false, settings.colorAccent, settings.colorSeconds);
}

void renderColorDemo() {
  clearPixels();
  for (uint8_t l = 0; l < LOGICAL_COUNT; l++) {
    setLogical(l, colorWheel(demoHue + l * 6));
  }
  pixels.show();
}

void refreshDisplay() {
  switch (settings.mode) {
    case MODE_CLOCK: renderClockFace(); break;
    case MODE_SECONDS: renderSecondsFace(); break;
    case MODE_TIMER: renderTimerFace(); break;
    case MODE_STOPWATCH: renderStopwatchFace(); break;
    case MODE_COLOR_DEMO: renderColorDemo(); break;
    default: renderClockFace(); break;
  }
}

void sendOk(const String& tag) {
  Serial.print(F("OK "));
  Serial.println(tag);
}

void sendErr(uint8_t code, const String& msg) {
  Serial.print(F("ERR "));
  Serial.print(code);
  Serial.print(F(" "));
  Serial.println(msg);
}

uint32_t parseHexColor(const String& s) {
  String t = s;
  if (t.startsWith("#")) t.remove(0, 1);
  return strtoul(t.c_str(), nullptr, 16);
}

void printStatus() {
  Serial.print(F("STATUS MODE="));
  Serial.print(settings.mode);
  Serial.print(F(" BRIGHTNESS="));
  Serial.print(settings.brightness);
  Serial.print(F(" RTC="));
  Serial.print(rtcPresent ? 1 : 0);
  Serial.print(F(" TIMER="));
  Serial.print(timerRunning ? 1 : 0);
  Serial.print(F(" H24="));
  Serial.print(settings.hour24);
  Serial.print(F(" CLOCK="));
  Serial.print(settings.colorClock, HEX);
  Serial.print(F(" ACCENT="));
  Serial.print(settings.colorAccent, HEX);
  Serial.print(F(" SECONDS="));
  Serial.print(settings.colorSeconds, HEX);
  Serial.print(F(" TIMERCOLOR="));
  Serial.println(settings.colorTimer, HEX);
}

void dumpMapCSV() {
  Serial.print(F("MAP "));
  for (uint8_t i = 0; i < NUM_PIXELS; i++) {
    Serial.print(physToLogical[i]);
    if (i + 1 < NUM_PIXELS) Serial.print(',');
  }
  Serial.println();
}

void setTimeFromFields(int year, int month, int day, int hour, int minute, int second) {
  if (!rtcPresent) return;
  rtc.adjust(DateTime(year, month, day, hour, minute, second));
}

void processCommand(const String& rawLine) {
  String line = rawLine;
  line.trim();
  if (!line.length()) return;

  if (line.startsWith("HELLO")) {
    Serial.print(F("OK HELLO SmartClock/1 FW=1.0 PIXELS="));
    Serial.print(NUM_PIXELS);
    Serial.print(F(" RTC="));
    Serial.println(rtcPresent ? 1 : 0);
    return;
  }

  if (line == "INFO?") {
    Serial.println(F("OK INFO BOARD=Leonardo PIN=5 BUTTONS=8,9,10 RTC=DS3231 I2C=D2,D3"));
    return;
  }

  if (line == "STATUS?") {
    printStatus();
    return;
  }

  if (line == "MAP?") {
    dumpMapCSV();
    return;
  }

  if (line == "SAVE MAP") {
    if (!validateNoDuplicates()) {
      sendErr(10, F("duplicate logical ids"));
      return;
    }
    saveMap();
    sendOk(F("SAVE MAP"));
    return;
  }

  if (line == "LOAD MAP") {
    if (loadMap()) sendOk(F("LOAD MAP"));
    else sendErr(11, F("no saved map"));
    return;
  }

  if (line == "SAVE SETTINGS") {
    saveSettings();
    sendOk(F("SAVE SETTINGS"));
    return;
  }

  if (line == "DEFAULT SETTINGS") {
    setDefaultSettings();
    pixels.setBrightness(settings.brightness);
    refreshDisplay();
    sendOk(F("DEFAULT SETTINGS"));
    return;
  }

  if (line.startsWith("MODE ")) {
    int mode = line.substring(5).toInt();
    if (mode < 0 || mode >= MODE_COUNT) {
      sendErr(12, F("bad mode"));
      return;
    }
    settings.mode = mode;
    refreshDisplay();
    sendOk(F("MODE"));
    return;
  }

  if (line.startsWith("BRIGHTNESS ")) {
    int b = line.substring(11).toInt();
    if (b < 0 || b > 255) {
      sendErr(13, F("bad brightness"));
      return;
    }
    settings.brightness = static_cast<uint8_t>(b);
    pixels.setBrightness(settings.brightness);
    refreshDisplay();
    sendOk(F("BRIGHTNESS"));
    return;
  }

  if (line.startsWith("COLOR ")) {
    int sep1 = line.indexOf(' ', 6);
    if (sep1 < 0) {
      sendErr(14, F("usage COLOR <slot> <RRGGBB>"));
      return;
    }
    String slot = line.substring(6, sep1);
    String value = line.substring(sep1 + 1);
    uint32_t c = parseHexColor(value);
    if (slot == "CLOCK") settings.colorClock = c;
    else if (slot == "ACCENT") settings.colorAccent = c;
    else if (slot == "SECONDS") settings.colorSeconds = c;
    else if (slot == "TIMER") settings.colorTimer = c;
    else {
      sendErr(15, F("unknown color slot"));
      return;
    }
    refreshDisplay();
    sendOk(F("COLOR"));
    return;
  }

  if (line.startsWith("TIME ")) {
    if (!rtcPresent) {
      sendErr(16, F("rtc missing"));
      return;
    }
    int y, mo, d, h, mi, s;
    if (sscanf(line.c_str(), "TIME %d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &s) == 6) {
      setTimeFromFields(y, mo, d, h, mi, s);
      refreshDisplay();
      sendOk(F("TIME"));
      return;
    }
    sendErr(17, F("time format YYYY-MM-DD HH:MM:SS"));
    return;
  }

  if (line == "RTC SYNC_COMPILE") {
    if (!rtcPresent) {
      sendErr(18, F("rtc missing"));
      return;
    }
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
    sendOk(F("RTC SYNC_COMPILE"));
    return;
  }

  if (line == "RTC?" || line == "TIME?") {
    if (!rtcPresent) {
      sendErr(19, F("rtc missing"));
      return;
    }
    DateTime now = rtc.now();
    char buf[24];
    snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d", now.year(), now.month(), now.day(), now.hour(), now.minute(), now.second());
    Serial.print(F("TIME "));
    Serial.println(buf);
    return;
  }

  if (line == "TOGGLE H24") {
    settings.hour24 = settings.hour24 ? 0 : 1;
    refreshDisplay();
    sendOk(F("TOGGLE H24"));
    return;
  }

  if (line == "TOGGLE LEADINGZERO") {
    settings.showLeadingZero = settings.showLeadingZero ? 0 : 1;
    refreshDisplay();
    sendOk(F("TOGGLE LEADINGZERO"));
    return;
  }

  if (line == "TOGGLE BLINK") {
    settings.colonBlink = settings.colonBlink ? 0 : 1;
    refreshDisplay();
    sendOk(F("TOGGLE BLINK"));
    return;
  }

  if (line.startsWith("TIMER SET ")) {
    long seconds = line.substring(10).toInt();
    if (seconds < 0 || seconds > 5999) {
      sendErr(20, F("timer range 0..5999"));
      return;
    }
    timerDurationSec = static_cast<uint32_t>(seconds);
    timerRunning = false;
    refreshDisplay();
    sendOk(F("TIMER SET"));
    return;
  }

  if (line == "TIMER START") {
    if (!rtcPresent) {
      sendErr(21, F("rtc missing"));
      return;
    }
    timerEndUnix = rtc.now().unixtime() + timerDurationSec;
    timerRunning = true;
    settings.mode = MODE_TIMER;
    refreshDisplay();
    sendOk(F("TIMER START"));
    return;
  }

  if (line == "TIMER STOP") {
    timerRunning = false;
    refreshDisplay();
    sendOk(F("TIMER STOP"));
    return;
  }

  if (line == "STOPWATCH START") {
    if (!stopwatchRunning) {
      stopwatchStartedAtMs = millis();
      stopwatchRunning = true;
    }
    settings.mode = MODE_STOPWATCH;
    sendOk(F("STOPWATCH START"));
    return;
  }

  if (line == "STOPWATCH STOP") {
    if (stopwatchRunning) {
      stopwatchAccumulatedMs += millis() - stopwatchStartedAtMs;
      stopwatchRunning = false;
    }
    sendOk(F("STOPWATCH STOP"));
    return;
  }

  if (line == "STOPWATCH RESET") {
    stopwatchRunning = false;
    stopwatchAccumulatedMs = 0;
    stopwatchStartedAtMs = 0;
    refreshDisplay();
    sendOk(F("STOPWATCH RESET"));
    return;
  }

  if (line == "TEST DIGITS") {
    for (uint8_t n = 0; n < 10; n++) {
      renderDigitsRaw(n, (n + 1) % 10, (n + 2) % 10, (n + 3) % 10, true, false, settings.colorClock, settings.colorAccent);
      delay(300);
    }
    refreshDisplay();
    sendOk(F("TEST DIGITS"));
    return;
  }

  if (line == "TEST SEGMENTS") {
    for (uint8_t l = 0; l < LOGICAL_COUNT; l++) {
      clearPixels();
      setLogical(l, settings.colorAccent);
      pixels.show();
      delay(180);
    }
    refreshDisplay();
    sendOk(F("TEST SEGMENTS"));
    return;
  }

  sendErr(255, F("unknown cmd"));
}

bool readLine(String& out) {
  while (Serial.available()) {
    char c = static_cast<char>(Serial.read());
    if (c == '\r') continue;
    if (c == '\n') return true;
    out += c;
    if (out.length() > 120) {
      out = "";
      return false;
    }
  }
  return false;
}

void handleButton(ButtonState& b, uint8_t index) {
  bool pressedNow = (digitalRead(b.pin) == LOW); // active-low buttons
  uint32_t nowMs = millis();
  if (pressedNow != b.lastRead) {
    b.lastChangeMs = nowMs;
    b.lastRead = pressedNow;
  }
  if ((nowMs - b.lastChangeMs) < 20) return;

  if (pressedNow != b.stablePressed) {
    b.stablePressed = pressedNow;
    if (pressedNow) {
      b.pressedAtMs = nowMs;
    } else {
      uint32_t held = nowMs - b.pressedAtMs;
      bool longPress = held >= 700;
      if (index == 1) {
        if (longPress) {
          settings.hour24 = settings.hour24 ? 0 : 1;
        } else {
          settings.mode = (settings.mode + 1) % MODE_COUNT;
        }
      } else if (index == 2) {
        if (longPress) {
          settings.brightness = (settings.brightness < 208) ? settings.brightness + 48 : 16;
          pixels.setBrightness(settings.brightness);
        } else {
          settings.colorClock = colorWheel(demoHue);
          settings.colorAccent = colorWheel(demoHue + 64);
          demoHue += 16;
        }
      } else if (index == 3) {
        if (settings.mode == MODE_TIMER) {
          if (longPress) {
            if (timerRunning) timerRunning = false;
            else if (rtcPresent) {
              timerEndUnix = rtc.now().unixtime() + timerDurationSec;
              timerRunning = true;
            }
          } else {
            timerDurationSec += 60;
            if (timerDurationSec > 5999) timerDurationSec = 60;
          }
        } else if (settings.mode == MODE_STOPWATCH) {
          if (longPress) {
            stopwatchRunning = false;
            stopwatchAccumulatedMs = 0;
            stopwatchStartedAtMs = 0;
          } else {
            if (stopwatchRunning) {
              stopwatchAccumulatedMs += millis() - stopwatchStartedAtMs;
              stopwatchRunning = false;
            } else {
              stopwatchStartedAtMs = millis();
              stopwatchRunning = true;
            }
          }
        } else {
          settings.colonBlink = settings.colonBlink ? 0 : 1;
        }
      }
      saveSettings();
      refreshDisplay();
    }
  }
}

void setupButtons() {
  pinMode(BTN1_PIN, INPUT_PULLUP);
  pinMode(BTN2_PIN, INPUT_PULLUP);
  pinMode(BTN3_PIN, INPUT_PULLUP);
}

void setupRtc() {
  Wire.begin();
  rtcPresent = rtc.begin();
  if (rtcPresent && rtc.lostPower()) {
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }
}

void setup() {
  Serial.begin(115200);
  pixels.begin();
  setupButtons();
  setupRtc();
  setDefaultIdentityMap();
  loadMap();
  loadSettings();
  pixels.setBrightness(settings.brightness);
  refreshDisplay();
}

void loop() {
  static String line;
  if (readLine(line)) {
    processCommand(line);
    line = "";
  }

  handleButton(btn1, 1);
  handleButton(btn2, 2);
  handleButton(btn3, 3);

  uint32_t nowMs = millis();
  if (settings.colonBlink && (nowMs - lastBlinkMs >= 500)) {
    colonState = !colonState;
    lastBlinkMs = nowMs;
    timeDirty = true;
  }

  if (settings.mode == MODE_COLOR_DEMO && (nowMs - lastDemoMs >= 80)) {
    demoHue++;
    lastDemoMs = nowMs;
    timeDirty = true;
  }

  if (nowMs - lastDisplayMs >= 100 || timeDirty) {
    refreshDisplay();
    lastDisplayMs = nowMs;
    timeDirty = false;
  }
}
