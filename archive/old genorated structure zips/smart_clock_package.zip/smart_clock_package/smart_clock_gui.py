from __future__ import annotations

import sys
from datetime import datetime
from typing import Optional

import serial
import serial.tools.list_ports
from PySide6 import QtCore, QtGui, QtWidgets


class SerialWorker(QtCore.QObject):
    line_rx = QtCore.Signal(str)
    status = QtCore.Signal(str)
    connected = QtCore.Signal(bool)

    def __init__(self) -> None:
        super().__init__()
        self._ser: Optional[serial.Serial] = None
        self._timer = QtCore.QTimer()
        self._timer.setInterval(20)
        self._timer.timeout.connect(self._poll)

    @QtCore.Slot(str)
    def connect_port(self, port: str) -> None:
        try:
            if self._ser and self._ser.is_open:
                self._ser.close()
            self._ser = serial.Serial(port=port, baudrate=115200, timeout=0)
            self._timer.start()
            self.status.emit(f"Connected: {port}")
            self.connected.emit(True)
        except Exception as e:
            self.status.emit(f"Connect failed: {e}")
            self.connected.emit(False)

    @QtCore.Slot()
    def disconnect_port(self) -> None:
        if self._ser:
            try:
                self._ser.close()
            except Exception:
                pass
        self._ser = None
        self._timer.stop()
        self.status.emit("Disconnected")
        self.connected.emit(False)

    @QtCore.Slot(str)
    def send(self, line: str) -> None:
        if not self._ser:
            self.status.emit("Not connected")
            return
        try:
            self._ser.write((line.strip() + "\n").encode("utf-8"))
            self.status.emit(f">> {line.strip()}")
        except Exception as e:
            self.status.emit(f"Write failed: {e}")

    def _poll(self) -> None:
        if not self._ser:
            return
        try:
            while self._ser.in_waiting:
                raw = self._ser.readline()
                if not raw:
                    break
                self.line_rx.emit(raw.decode("utf-8", errors="replace").strip())
        except Exception as e:
            self.status.emit(f"Serial error: {e}")
            self.disconnect_port()


class ColorButton(QtWidgets.QPushButton):
    color_changed = QtCore.Signal(str)

    def __init__(self, label: str, initial: str) -> None:
        super().__init__(label)
        self._hex = initial.upper()
        self.clicked.connect(self.pick_color)
        self.update_style()

    def hex_color(self) -> str:
        return self._hex

    def set_hex(self, value: str) -> None:
        value = value.replace("#", "").upper()
        if len(value) == 6:
            self._hex = value
            self.update_style()
            self.color_changed.emit(self._hex)

    def pick_color(self) -> None:
        col = QtWidgets.QColorDialog.getColor(QtGui.QColor(f"#{self._hex}"), self, "Pick color")
        if col.isValid():
            self._hex = col.name().replace("#", "").upper()
            self.update_style()
            self.color_changed.emit(self._hex)

    def update_style(self) -> None:
        self.setText(f"#{self._hex}")
        self.setStyleSheet(f"background-color: #{self._hex};")


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Smart Clock Control")
        self.resize(1020, 720)

        self.worker = SerialWorker()
        self.thread = QtCore.QThread(self)
        self.worker.moveToThread(self.thread)
        self.thread.start()

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        layout = QtWidgets.QVBoxLayout(central)

        # top row
        top_row = QtWidgets.QHBoxLayout()
        self.port_box = QtWidgets.QComboBox()
        self.refresh_ports()
        self.refresh_btn = QtWidgets.QPushButton("Refresh Ports")
        self.connect_btn = QtWidgets.QPushButton("Connect")
        self.disconnect_btn = QtWidgets.QPushButton("Disconnect")
        top_row.addWidget(QtWidgets.QLabel("Port:"))
        top_row.addWidget(self.port_box, 1)
        top_row.addWidget(self.refresh_btn)
        top_row.addWidget(self.connect_btn)
        top_row.addWidget(self.disconnect_btn)
        layout.addLayout(top_row)

        tabs = QtWidgets.QTabWidget()
        layout.addWidget(tabs, 1)

        # Control tab
        control_tab = QtWidgets.QWidget()
        tabs.addTab(control_tab, "Clock Control")
        control_layout = QtWidgets.QVBoxLayout(control_tab)

        mode_group = QtWidgets.QGroupBox("Display Mode")
        mode_layout = QtWidgets.QHBoxLayout(mode_group)
        self.mode_box = QtWidgets.QComboBox()
        self.mode_box.addItems([
            "0 - Clock",
            "1 - MM:SS",
            "2 - Timer",
            "3 - Stopwatch",
            "4 - Color Demo",
        ])
        self.mode_send_btn = QtWidgets.QPushButton("Set Mode")
        self.status_btn = QtWidgets.QPushButton("Query Status")
        mode_layout.addWidget(self.mode_box, 1)
        mode_layout.addWidget(self.mode_send_btn)
        mode_layout.addWidget(self.status_btn)
        control_layout.addWidget(mode_group)

        brightness_group = QtWidgets.QGroupBox("Brightness")
        brightness_layout = QtWidgets.QHBoxLayout(brightness_group)
        self.brightness_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.brightness_slider.setRange(1, 255)
        self.brightness_slider.setValue(48)
        self.brightness_value = QtWidgets.QLabel("48")
        self.brightness_send_btn = QtWidgets.QPushButton("Apply")
        brightness_layout.addWidget(self.brightness_slider, 1)
        brightness_layout.addWidget(self.brightness_value)
        brightness_layout.addWidget(self.brightness_send_btn)
        control_layout.addWidget(brightness_group)

        opts_group = QtWidgets.QGroupBox("Quick Toggles")
        opts_layout = QtWidgets.QHBoxLayout(opts_group)
        self.toggle_h24_btn = QtWidgets.QPushButton("Toggle 12/24h")
        self.toggle_lz_btn = QtWidgets.QPushButton("Toggle Leading Zero")
        self.toggle_blink_btn = QtWidgets.QPushButton("Toggle Colon Blink")
        opts_layout.addWidget(self.toggle_h24_btn)
        opts_layout.addWidget(self.toggle_lz_btn)
        opts_layout.addWidget(self.toggle_blink_btn)
        control_layout.addWidget(opts_group)

        rtc_group = QtWidgets.QGroupBox("RTC / DS3231")
        rtc_layout = QtWidgets.QGridLayout(rtc_group)
        self.time_edit = QtWidgets.QDateTimeEdit(QtCore.QDateTime.currentDateTime())
        self.time_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        self.set_time_btn = QtWidgets.QPushButton("Set RTC From Above")
        self.pc_time_btn = QtWidgets.QPushButton("Set RTC From PC Time")
        self.read_time_btn = QtWidgets.QPushButton("Read RTC")
        rtc_layout.addWidget(QtWidgets.QLabel("Date/Time:"), 0, 0)
        rtc_layout.addWidget(self.time_edit, 0, 1, 1, 2)
        rtc_layout.addWidget(self.set_time_btn, 1, 0)
        rtc_layout.addWidget(self.pc_time_btn, 1, 1)
        rtc_layout.addWidget(self.read_time_btn, 1, 2)
        control_layout.addWidget(rtc_group)

        timer_group = QtWidgets.QGroupBox("Timer / Stopwatch")
        timer_layout = QtWidgets.QGridLayout(timer_group)
        self.timer_minutes = QtWidgets.QSpinBox()
        self.timer_minutes.setRange(0, 99)
        self.timer_seconds = QtWidgets.QSpinBox()
        self.timer_seconds.setRange(0, 59)
        self.timer_set_btn = QtWidgets.QPushButton("Set Timer")
        self.timer_start_btn = QtWidgets.QPushButton("Start Timer")
        self.timer_stop_btn = QtWidgets.QPushButton("Stop Timer")
        self.sw_start_btn = QtWidgets.QPushButton("Start Stopwatch")
        self.sw_stop_btn = QtWidgets.QPushButton("Stop Stopwatch")
        self.sw_reset_btn = QtWidgets.QPushButton("Reset Stopwatch")
        timer_layout.addWidget(QtWidgets.QLabel("Min"), 0, 0)
        timer_layout.addWidget(self.timer_minutes, 0, 1)
        timer_layout.addWidget(QtWidgets.QLabel("Sec"), 0, 2)
        timer_layout.addWidget(self.timer_seconds, 0, 3)
        timer_layout.addWidget(self.timer_set_btn, 0, 4)
        timer_layout.addWidget(self.timer_start_btn, 1, 0)
        timer_layout.addWidget(self.timer_stop_btn, 1, 1)
        timer_layout.addWidget(self.sw_start_btn, 1, 2)
        timer_layout.addWidget(self.sw_stop_btn, 1, 3)
        timer_layout.addWidget(self.sw_reset_btn, 1, 4)
        control_layout.addWidget(timer_group)

        test_group = QtWidgets.QGroupBox("Test Patterns")
        test_layout = QtWidgets.QHBoxLayout(test_group)
        self.test_digits_btn = QtWidgets.QPushButton("Run Digit Test")
        self.test_segments_btn = QtWidgets.QPushButton("Run Segment Test")
        self.map_btn = QtWidgets.QPushButton("Read Mapping")
        test_layout.addWidget(self.test_digits_btn)
        test_layout.addWidget(self.test_segments_btn)
        test_layout.addWidget(self.map_btn)
        control_layout.addWidget(test_group)
        control_layout.addStretch(1)

        # color tab
        color_tab = QtWidgets.QWidget()
        tabs.addTab(color_tab, "Colors")
        color_layout = QtWidgets.QVBoxLayout(color_tab)

        colors_grid = QtWidgets.QGridLayout()
        self.color_clock = ColorButton("Clock", "FF7A18")
        self.color_accent = ColorButton("Accent", "2080FF")
        self.color_seconds = ColorButton("Seconds", "00C878")
        self.color_timer = ColorButton("Timer", "FF1010")
        self.send_clock = QtWidgets.QPushButton("Send Clock Color")
        self.send_accent = QtWidgets.QPushButton("Send Accent Color")
        self.send_seconds = QtWidgets.QPushButton("Send Seconds Color")
        self.send_timer = QtWidgets.QPushButton("Send Timer Color")

        labels = ["Clock digits", "Accent / colon", "Seconds mode", "Timer mode"]
        buttons = [self.color_clock, self.color_accent, self.color_seconds, self.color_timer]
        senders = [self.send_clock, self.send_accent, self.send_seconds, self.send_timer]
        for row, (label, btn, send_btn) in enumerate(zip(labels, buttons, senders)):
            colors_grid.addWidget(QtWidgets.QLabel(label), row, 0)
            colors_grid.addWidget(btn, row, 1)
            colors_grid.addWidget(send_btn, row, 2)
        color_layout.addLayout(colors_grid)

        save_row = QtWidgets.QHBoxLayout()
        self.save_settings_btn = QtWidgets.QPushButton("Save Settings to EEPROM")
        self.default_settings_btn = QtWidgets.QPushButton("Load Defaults")
        save_row.addWidget(self.save_settings_btn)
        save_row.addWidget(self.default_settings_btn)
        color_layout.addLayout(save_row)
        color_layout.addStretch(1)

        # log tab
        log_tab = QtWidgets.QWidget()
        tabs.addTab(log_tab, "Serial Log")
        log_layout = QtWidgets.QVBoxLayout(log_tab)
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        log_layout.addWidget(self.log)

        self.brightness_slider.valueChanged.connect(lambda v: self.brightness_value.setText(str(v)))
        self.refresh_btn.clicked.connect(self.refresh_ports)
        self.connect_btn.clicked.connect(self.connect_selected_port)
        self.disconnect_btn.clicked.connect(lambda: QtCore.QMetaObject.invokeMethod(self.worker, "disconnect_port", QtCore.Qt.QueuedConnection))
        self.mode_send_btn.clicked.connect(self.send_mode)
        self.status_btn.clicked.connect(lambda: self.send_line("STATUS?"))
        self.brightness_send_btn.clicked.connect(self.send_brightness)
        self.toggle_h24_btn.clicked.connect(lambda: self.send_line("TOGGLE H24"))
        self.toggle_lz_btn.clicked.connect(lambda: self.send_line("TOGGLE LEADINGZERO"))
        self.toggle_blink_btn.clicked.connect(lambda: self.send_line("TOGGLE BLINK"))
        self.set_time_btn.clicked.connect(self.send_selected_time)
        self.pc_time_btn.clicked.connect(self.send_pc_time)
        self.read_time_btn.clicked.connect(lambda: self.send_line("TIME?"))
        self.timer_set_btn.clicked.connect(self.send_timer_set)
        self.timer_start_btn.clicked.connect(lambda: self.send_line("TIMER START"))
        self.timer_stop_btn.clicked.connect(lambda: self.send_line("TIMER STOP"))
        self.sw_start_btn.clicked.connect(lambda: self.send_line("STOPWATCH START"))
        self.sw_stop_btn.clicked.connect(lambda: self.send_line("STOPWATCH STOP"))
        self.sw_reset_btn.clicked.connect(lambda: self.send_line("STOPWATCH RESET"))
        self.test_digits_btn.clicked.connect(lambda: self.send_line("TEST DIGITS"))
        self.test_segments_btn.clicked.connect(lambda: self.send_line("TEST SEGMENTS"))
        self.map_btn.clicked.connect(lambda: self.send_line("MAP?"))
        self.send_clock.clicked.connect(lambda: self.send_color("CLOCK", self.color_clock.hex_color()))
        self.send_accent.clicked.connect(lambda: self.send_color("ACCENT", self.color_accent.hex_color()))
        self.send_seconds.clicked.connect(lambda: self.send_color("SECONDS", self.color_seconds.hex_color()))
        self.send_timer.clicked.connect(lambda: self.send_color("TIMER", self.color_timer.hex_color()))
        self.save_settings_btn.clicked.connect(lambda: self.send_line("SAVE SETTINGS"))
        self.default_settings_btn.clicked.connect(lambda: self.send_line("DEFAULT SETTINGS"))

        self.worker.line_rx.connect(self.on_line)
        self.worker.status.connect(self.append_log)
        self.worker.connected.connect(self.on_connected)

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        QtCore.QMetaObject.invokeMethod(self.worker, "disconnect_port", QtCore.Qt.QueuedConnection)
        self.thread.quit()
        self.thread.wait(1000)
        super().closeEvent(event)

    def append_log(self, text: str) -> None:
        self.log.appendPlainText(text)

    def refresh_ports(self) -> None:
        current = self.port_box.currentText()
        self.port_box.clear()
        ports = [p.device for p in serial.tools.list_ports.comports()]
        self.port_box.addItems(ports)
        if current in ports:
            self.port_box.setCurrentText(current)

    def connect_selected_port(self) -> None:
        port = self.port_box.currentText().strip()
        if not port:
            self.append_log("No port selected")
            return
        QtCore.QMetaObject.invokeMethod(
            self.worker,
            "connect_port",
            QtCore.Qt.QueuedConnection,
            QtCore.Q_ARG(str, port),
        )

    def send_line(self, text: str) -> None:
        QtCore.QMetaObject.invokeMethod(
            self.worker,
            "send",
            QtCore.Qt.QueuedConnection,
            QtCore.Q_ARG(str, text),
        )

    def send_mode(self) -> None:
        mode = self.mode_box.currentIndex()
        self.send_line(f"MODE {mode}")

    def send_brightness(self) -> None:
        self.send_line(f"BRIGHTNESS {self.brightness_slider.value()}")

    def send_selected_time(self) -> None:
        dt = self.time_edit.dateTime().toPython()
        self.send_line(f"TIME {dt:%Y-%m-%d %H:%M:%S}")

    def send_pc_time(self) -> None:
        dt = datetime.now()
        self.send_line(f"TIME {dt:%Y-%m-%d %H:%M:%S}")

    def send_timer_set(self) -> None:
        total = self.timer_minutes.value() * 60 + self.timer_seconds.value()
        self.send_line(f"TIMER SET {total}")

    def send_color(self, slot: str, color_hex: str) -> None:
        self.send_line(f"COLOR {slot} {color_hex}")

    def on_connected(self, ok: bool) -> None:
        if ok:
            self.send_line("HELLO SmartClock/1")
            QtCore.QTimer.singleShot(150, lambda: self.send_line("STATUS?"))
        self.connect_btn.setEnabled(not ok)
        self.disconnect_btn.setEnabled(ok)

    def on_line(self, line: str) -> None:
        self.append_log(f"<< {line}")
        if line.startswith("STATUS "):
            parts = {}
            for token in line.split()[1:]:
                if "=" in token:
                    k, v = token.split("=", 1)
                    parts[k] = v
            if "BRIGHTNESS" in parts:
                try:
                    self.brightness_slider.setValue(int(parts["BRIGHTNESS"]))
                except ValueError:
                    pass
            if "MODE" in parts:
                try:
                    mode = int(parts["MODE"])
                    if 0 <= mode < self.mode_box.count():
                        self.mode_box.setCurrentIndex(mode)
                except ValueError:
                    pass
            if "CLOCK" in parts:
                self.color_clock.set_hex(parts["CLOCK"].zfill(6)[-6:])
            if "ACCENT" in parts:
                self.color_accent.set_hex(parts["ACCENT"].zfill(6)[-6:])
            if "SECONDS" in parts:
                self.color_seconds.set_hex(parts["SECONDS"].zfill(6)[-6:])
            if "TIMERCOLOR" in parts:
                self.color_timer.set_hex(parts["TIMERCOLOR"].zfill(6)[-6:])
        elif line.startswith("TIME "):
            payload = line[5:].strip()
            try:
                dt = datetime.strptime(payload, "%Y-%m-%d %H:%M:%S")
                self.time_edit.setDateTime(QtCore.QDateTime(dt))
            except ValueError:
                pass


def main() -> None:
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
