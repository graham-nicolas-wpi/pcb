from __future__ import annotations
import json
import sys
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path
from typing import List, Optional, Set

import serial
from PySide6 import QtCore, QtWidgets

class LogicalId(IntEnum):
    D1_A = 0; D1_B = 1; D1_C = 2; D1_D = 3; D1_E = 4; D1_F = 5; D1_G = 6
    D2_A = 7; D2_B = 8; D2_C = 9; D2_D = 10; D2_E = 11; D2_F = 12; D2_G = 13
    COLON_TOP = 14
    COLON_BOTTOM = 15
    D3_A = 16; D3_B = 17; D3_C = 18; D3_D = 19; D3_E = 20; D3_F = 21; D3_G = 22
    D4_A = 23; D4_B = 24; D4_C = 25; D4_D = 26; D4_E = 27; D4_F = 28; D4_G = 29
    DECIMAL = 30

LOG_UNUSED = 255

@dataclass
class MappingModel:
    num_pixels: int = 31
    pixel_pin: int = 5
    phys_to_logical: List[int] = field(default_factory=lambda: [LOG_UNUSED] * 31)

    def assign(self, phys: int, logical: int) -> None:
        if not (0 <= phys < self.num_pixels):
            raise ValueError(f"phys index out of range: {phys}")
        self.phys_to_logical[phys] = logical

    def used_logicals(self) -> Set[int]:
        return {v for v in self.phys_to_logical if v != LOG_UNUSED}

    def validate(self) -> List[str]:
        errors: List[str] = []
        used = [v for v in self.phys_to_logical if v != LOG_UNUSED]
        if len(used) != len(set(used)):
            errors.append("Duplicate logical assignment detected.")
        expected = set(int(x) for x in LogicalId)
        missing = sorted(expected - self.used_logicals())
        if missing:
            errors.append(f"Unassigned logical positions: {len(missing)}")
        return errors

    def to_json_obj(self) -> dict:
        names = []
        for v in self.phys_to_logical:
            names.append("UNUSED" if v == LOG_UNUSED else LogicalId(v).name)
        return {
            "schema": "neopixel-clock-map/v1",
            "num_pixels": self.num_pixels,
            "pixel_pin": self.pixel_pin,
            "color_order": "GRB",
            "phys_to_logical": names,
            "notes": {"digit_order": "D1 D2 : D3 D4"},
        }

    def export_header(self) -> str:
        logical_count = len(list(LogicalId))
        logical_to_phys = [255] * logical_count
        for phys, logical in enumerate(self.phys_to_logical):
            if logical != LOG_UNUSED and logical < logical_count:
                logical_to_phys[logical] = phys

        def arr(vals: List[int]) -> str:
            return "{ " + ", ".join(str(v) for v in vals) + " }"

        return "\n".join([
            "#pragma once",
            "#include <stdint.h>",
            "#include \"LogicalIds.h\"",
            "",
            f"constexpr uint8_t kPhysToLogical[kNumPixels] = {arr(self.phys_to_logical)};",
            f"constexpr uint8_t kLogicalToPhys[LOGICAL_COUNT] = {arr(logical_to_phys)};",
            "",
        ])

class SerialWorker(QtCore.QObject):
    line_rx = QtCore.Signal(str)
    connected = QtCore.Signal(bool, str)

    def __init__(self) -> None:
        super().__init__()
        self._ser: Optional[serial.Serial] = None
        self._timer = QtCore.QTimer()
        self._timer.setInterval(10)
        self._timer.timeout.connect(self._poll)

    @QtCore.Slot(str)
    def connect_port(self, port: str) -> None:
        try:
            self._ser = serial.Serial(port=port, baudrate=115200, timeout=0)
            self._timer.start()
            self.connected.emit(True, f"Connected: {port}")
        except Exception as e:
            self.connected.emit(False, f"Connect failed: {e}")

    def send(self, line: str) -> None:
        if not self._ser:
            return
        self._ser.write((line.strip() + "\n").encode("utf-8"))

    def _poll(self) -> None:
        if not self._ser:
            return
        try:
            while self._ser.in_waiting:
                raw = self._ser.readline()
                if not raw:
                    break
                self.line_rx.emit(raw.decode("utf-8", errors="replace").strip())
        except Exception as e:
            self.connected.emit(False, f"Serial error: {e}")
            self._timer.stop()
            self._ser = None

class MainWindow(QtWidgets.QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("ClockCal")
        self.model = MappingModel()
        self.cur_phys = 0

        self.port_box = QtWidgets.QLineEdit()
        self.port_box.setPlaceholderText("COM3 or /dev/ttyACM0")
        self.connect_btn = QtWidgets.QPushButton("Connect")
        self.hello_btn = QtWidgets.QPushButton("HELLO")
        self.info_btn = QtWidgets.QPushButton("INFO?")
        self.prev_btn = QtWidgets.QPushButton("Prev")
        self.next_btn = QtWidgets.QPushButton("Next")
        self.map_btn = QtWidgets.QPushButton("MAP?")
        self.validate_btn = QtWidgets.QPushButton("VALIDATE?")
        self.test_seg_btn = QtWidgets.QPushButton("TEST SEGMENTS")
        self.test_digits_btn = QtWidgets.QPushButton("TEST DIGITS")
        self.save_dev_btn = QtWidgets.QPushButton("SAVE to Device")
        self.load_dev_btn = QtWidgets.QPushButton("LOAD from Device")
        self.logical_box = QtWidgets.QComboBox()
        self.logical_box.addItem("UNUSED", LOG_UNUSED)
        for lid in LogicalId:
            self.logical_box.addItem(lid.name, int(lid))
        self.assign_btn = QtWidgets.QPushButton("Assign + Next")
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.save_json_btn = QtWidgets.QPushButton("Save JSON")
        self.save_h_btn = QtWidgets.QPushButton("Export .h")

        layout = QtWidgets.QVBoxLayout(self)
        top = QtWidgets.QHBoxLayout()
        top.addWidget(self.port_box)
        top.addWidget(self.connect_btn)
        layout.addLayout(top)

        row1 = QtWidgets.QHBoxLayout()
        for w in [self.hello_btn, self.info_btn, self.prev_btn, self.next_btn, self.map_btn, self.validate_btn]:
            row1.addWidget(w)
        layout.addLayout(row1)

        row2 = QtWidgets.QHBoxLayout()
        row2.addWidget(self.logical_box)
        row2.addWidget(self.assign_btn)
        row2.addWidget(self.save_dev_btn)
        row2.addWidget(self.load_dev_btn)
        layout.addLayout(row2)

        row3 = QtWidgets.QHBoxLayout()
        row3.addWidget(self.test_seg_btn)
        row3.addWidget(self.test_digits_btn)
        row3.addWidget(self.save_json_btn)
        row3.addWidget(self.save_h_btn)
        layout.addLayout(row3)
        layout.addWidget(self.log)

        self.worker = SerialWorker()
        self.thread = QtCore.QThread()
        self.worker.moveToThread(self.thread)
        self.thread.start()

        self.connect_btn.clicked.connect(self._connect)
        self.hello_btn.clicked.connect(lambda: self.worker.send("HELLO ClockCal/1"))
        self.info_btn.clicked.connect(lambda: self.worker.send("INFO?"))
        self.prev_btn.clicked.connect(lambda: self.worker.send("PREV"))
        self.next_btn.clicked.connect(lambda: self.worker.send("NEXT"))
        self.map_btn.clicked.connect(lambda: self.worker.send("MAP?"))
        self.validate_btn.clicked.connect(lambda: self.worker.send("VALIDATE?"))
        self.test_seg_btn.clicked.connect(lambda: self.worker.send("TEST SEGMENTS"))
        self.test_digits_btn.clicked.connect(lambda: self.worker.send("TEST DIGITS"))
        self.save_dev_btn.clicked.connect(lambda: self.worker.send("SAVE"))
        self.load_dev_btn.clicked.connect(lambda: self.worker.send("LOAD"))
        self.assign_btn.clicked.connect(self._assign_next)
        self.save_json_btn.clicked.connect(self._save_json)
        self.save_h_btn.clicked.connect(self._save_h)
        self.worker.connected.connect(self._on_conn)
        self.worker.line_rx.connect(self._on_line)

    def _connect(self) -> None:
        port = self.port_box.text().strip()
        QtCore.QMetaObject.invokeMethod(
            self.worker, "connect_port", QtCore.Qt.QueuedConnection,
            QtCore.Q_ARG(str, port)
        )

    def _on_conn(self, ok: bool, msg: str) -> None:
        self.log.appendPlainText(msg)

    def _on_line(self, line: str) -> None:
        self.log.appendPlainText("<< " + line)
        if line.startswith("CUR "):
            self.cur_phys = int(line.split()[1])
        if line.startswith("MAP "):
            parts = [int(x) for x in line[4:].strip().split(",")]
            if len(parts) == self.model.num_pixels:
                self.model.phys_to_logical = parts
        if line.startswith("OK HELLO"):
            self.worker.send("CUR?")
            self.worker.send("MAP?")

    def _assign_next(self) -> None:
        logical = int(self.logical_box.currentData())
        if logical != LOG_UNUSED and logical in self.model.used_logicals():
            self.log.appendPlainText("!! Logical already used; choose another.")
            return
        self.model.assign(self.cur_phys, logical)
        self.worker.send(f"ASSIGN {logical}")
        self.worker.send("NEXT")
        self.worker.send("CUR?")

    def _save_json(self) -> None:
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save JSON", "ledmap.json", "JSON (*.json)")
        if not path:
            return
        Path(path).write_text(json.dumps(self.model.to_json_obj(), indent=2), encoding="utf-8")
        errs = self.model.validate()
        self.log.appendPlainText("Saved JSON. Validate: " + ("OK" if not errs else "; ".join(errs)))

    def _save_h(self) -> None:
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Export Header", "Generated_LedMap.h", "Header (*.h)")
        if not path:
            return
        Path(path).write_text(self.model.export_header(), encoding="utf-8")
        self.log.appendPlainText("Exported header.")

def main() -> None:
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.resize(1100, 650)
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
