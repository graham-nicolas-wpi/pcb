#include <Arduino.h>
#include "LogicalIds.h"
#include "LedMap.h"
#include "PixelDriver_NeoPixel.h"
#include "LogicalDisplay.h"
#include "Buttons.h"
#include "CalibrationController.h"

namespace Pins {
  static constexpr uint8_t kPixels = 5;
  static constexpr uint8_t kBtn1 = 8;
  static constexpr uint8_t kBtn2 = 9;
  static constexpr uint8_t kBtn3 = 10;
}

PixelDriver_NeoPixel gPixels(Pins::kPixels, kNumPixels);
LedMap gMap;
LogicalDisplay gDisplay(gPixels, gMap);
Buttons gButtons(Pins::kBtn1, Pins::kBtn2, Pins::kBtn3);
CalibrationController gCal(gPixels, gMap, gDisplay);

static uint32_t gLastBlinkMs = 0;
static bool gColonOn = false;
static uint8_t gCounter = 0;

static void renderDemoClock() {
  gDisplay.clear();
  gDisplay.renderDigit(0, (gCounter / 10) % 10, gPixels.color(255, 80, 20));
  gDisplay.renderDigit(1, gCounter % 10, gPixels.color(255, 80, 20));
  gDisplay.renderDigit(2, (gCounter / 10) % 10, gPixels.color(255, 80, 20));
  gDisplay.renderDigit(3, gCounter % 10, gPixels.color(255, 80, 20));
  gDisplay.setColon(gColonOn, gColonOn, gPixels.color(0, 80, 255));
  gDisplay.show();
}

void setup() {
  Serial.begin(115200);
  gPixels.begin();
  gPixels.setBrightness(64);
  gButtons.begin();
  gMap.loadOrDefault();
  gMap.buildInverse();
  gCal.begin();
}

void loop() {
  gButtons.update();
  gCal.processSerial();

  if (gButtons.wasShortPressed(Buttons::ButtonId::BTN1)) gCal.setCalibrationMode(!gCal.isCalibrationMode());
  if (gButtons.wasShortPressed(Buttons::ButtonId::BTN2)) gCal.nextPhys(+1);
  if (gButtons.wasShortPressed(Buttons::ButtonId::BTN3)) gCal.nextPhys(-1);

  if (!gCal.isCalibrationMode()) {
    const uint32_t now = millis();
    if (now - gLastBlinkMs >= 500) {
      gLastBlinkMs = now;
      gColonOn = !gColonOn;
      if (gColonOn) gCounter = (gCounter + 1) % 100;
      renderDemoClock();
    }
  }
}
