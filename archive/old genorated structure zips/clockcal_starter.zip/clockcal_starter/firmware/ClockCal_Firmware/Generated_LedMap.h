#pragma once
#include <stdint.h>
#include "LogicalIds.h"

// Placeholder identity map. Replace after calibration.
constexpr uint8_t kPhysToLogical[kNumPixels] = {
  0, 1, 2, 3, 4, 5, 6,
  7, 8, 9, 10, 11, 12, 13,
  14, 15,
  16, 17, 18, 19, 20, 21, 22,
  23, 24, 25, 26, 27, 28, 29,
  30
};

constexpr uint8_t kLogicalToPhys[LOGICAL_COUNT] = {
  0, 1, 2, 3, 4, 5, 6,
  7, 8, 9, 10, 11, 12, 13,
  14, 15,
  16, 17, 18, 19, 20, 21, 22,
  23, 24, 25, 26, 27, 28, 29,
  30
};
